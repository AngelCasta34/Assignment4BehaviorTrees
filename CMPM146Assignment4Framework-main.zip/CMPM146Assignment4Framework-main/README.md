# Framework for CMPM 146 - Assignment 4

This framework is for assignment 4 of the class CMPM 146 - Game AI. It was developed in Unity version 6000.0.23f, but should also work in other Unity versions. 

## Artwork

All art used in this framework was released under CC-0. 

Spell and relic icons:
https://opengameart.org/content/dungeon-crawl-32x32-tiles

Roguelike Dungeon tiles:
https://opengameart.org/content/roguelike-caves-dungeons-pack
https://kenney.nl/assets/roguelike-caves-dungeons

UI:
https://kenney.nl/assets/ui-pack-pixel-adventure

Enemy sprites:
https://opengameart.org/content/tiny-creatures

Arcane bolt projectile:
https://opengameart.org/content/arcane-magic-effect